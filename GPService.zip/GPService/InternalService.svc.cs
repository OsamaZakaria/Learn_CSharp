﻿using System.Collections.Generic;
using KFH.BusinessMangers;

namespace KFH.Service
{
    [System.ServiceModel.Activation.AspNetCompatibilityRequirements(
              RequirementsMode = System.ServiceModel.Activation.AspNetCompatibilityRequirementsMode.Allowed)]
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "InternalService" in code, svc and config file together.
    public class InternalService : KFH.Contracts.IFAService
    {
        public bool ExportPurchasedFAsToFixedAssets()
        {
           return KFH.BusinessMangers.FixedAssetsManger.ExportPurchasedFAsToFixedAssets();
        }

        public List<Library.FixedAssetClass> GetFixedAssetsClasses()
        {
            return FixedAssetsManger.GetAllFixedAssetClasses();
        }

        public string GenerateAssetID(string ClassID)
        {
            return FixedAssetsManger.GenerateAssetID(ClassID);
        }

        public List<Library.PurchaseOrderReportItem> GetPurchaseOrderReportData(string PONumber)
        {
            return PurchaseOrdersManger.GetPurchaseOrderReportData(PONumber);
        }


        public bool UpdatePurchaseOrderExtraInfo(Library.POExtraInfo updatedExtraInfo, out Message returnedMessage)
        {
            return PurchaseOrdersManger.UpdatePurchaseOrderExtraInfo(updatedExtraInfo,out returnedMessage);
        }

        public bool ISUpdateOperation(Library.POExtraInfo poExtraInfo)
        {
            return PurchaseOrdersManger.ISUpdateOperation(poExtraInfo);
        }

        public Library.POExtraInfo GetPOExtraInfo(string PONumber)
        {
            return PurchaseOrdersManger.GetPOExtraInfo(PONumber);   
        }
    }
}
