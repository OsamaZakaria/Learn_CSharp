﻿using System.Collections.Generic;

using KFH.Library;
using KFH.BusinessMangers;

namespace KFH.Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    [System.ServiceModel.Activation.AspNetCompatibilityRequirements(
           RequirementsMode = System.ServiceModel.Activation.AspNetCompatibilityRequirementsMode.Allowed)]
    public class BarcodeService : KFH.Contracts.IBarcodeService 
    {
        
        public List<FixedAssetsInformation> GetAllFixedAssets()
        {
            return FixedAssetsManger.GetAllFixedAssets();
        }


        public FixedAssetsInformation GetFixedAssetByFACode(string FACode, short AssetSuffix)
        {
            FixedAssetsInformation x= FixedAssetsManger. GetFixedAssetByFACode(FACode, AssetSuffix);
            return x;
        }

        
        public List<FixedAssetsInformation> GetFixedAssetsByFAClass(string FAClass)
        {
            return FixedAssetsManger.GetFixedAssetsByFAClass(FAClass);
        }

        
        public List<FixedAssetsInformation> GetFisxedAssetsByLocationCode (string LocationCode)
        {
            return FixedAssetsManger.GetFisxedAssetsByLocationCode(LocationCode);
        }

        
        public void UpdateFixedAssetsData(FixedAssetsInformation FAInfo)
        {
            FixedAssetsManger.UpdateFixedAssetsData(FAInfo); 
        }
    }
}
