﻿using System.Collections.Generic;

namespace KFH.Service
{
    [System.ServiceModel.Activation.AspNetCompatibilityRequirements(
              RequirementsMode = System.ServiceModel.Activation.AspNetCompatibilityRequirementsMode.Allowed)]
    public class PhoenixIntegrationService : KFH.Contracts.IPhoenixIntegration
    {


        public List<KFH.Library.GlTransactionEntry> PostGLsToPhoenix(string BACHNUMB, string userId, out List<KFH.BusinessMangers.Message> msg)
        {
            return KFH.BusinessMangers.PhoenixIntegrationsManger.PostGLsToPhoenix(BACHNUMB,userId , out msg);
        }

        public List<Library.PostedManualPaymentToPhoenix> PostManualPaymentToPhoenix(string BACHNUMB,string userId, out List<KFH.BusinessMangers.Message> msg)
        {
            return KFH.BusinessMangers.PhoenixIntegrationsManger.PostManualPaymentToPhoenix(BACHNUMB, userId, out msg);
        }


       

        public Library.GlTransactionEntry GetCheque(string BACHNUMB, int JRNENTRY)
        {
            return KFH.BusinessMangers.GlTransactionEntry.GetCheque(BACHNUMB, JRNENTRY);
        }

        public List<Library.ManualPaymentInvoiceDistributions> GetManualPaymentGLs(string PMNTNMBR)
        {
            return KFH.BusinessMangers.PhoenixIntegrationsManger.GetManualPaymentGLs(PMNTNMBR);
        }


        public bool SaveManualPaymentGLs(List<Library.ManualPaymentInvoiceDistributions> gls)
        {
            return KFH.BusinessMangers.PhoenixIntegrationsManger.SaveManualPaymentGLs(gls);
        }


        public List<KFH.Library.ManualPaymentCheque> GetManualPaymentCheque(string BACHNUMB, string PMNTNMBR)
        {
            return KFH.BusinessMangers.PhoenixIntegrationsManger.GetManualPaymentCheque(BACHNUMB, PMNTNMBR);
        }

        public List<KFH.Library.ManualPaymentPrint> GetManualPaymentPrint(string  PMNTNMBR)
        {
            return KFH.BusinessMangers.PhoenixIntegrationsManger.GetManualPaymentPrint(PMNTNMBR);
        }
    }
}


