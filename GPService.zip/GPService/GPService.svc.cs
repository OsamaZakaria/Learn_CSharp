﻿using System;
using System.Collections.Generic;
using KFH.BusinessMangers;
using KFH.Library;

namespace KFH.Service
{
    [System.ServiceModel.Activation.AspNetCompatibilityRequirements(
           RequirementsMode = System.ServiceModel.Activation.AspNetCompatibilityRequirementsMode.Allowed)]
    public class GPService : KFH.Contracts.IGPService
    {

        public List<Library.ManualPaymentSwiftReport> GetSwiftReport(string PMNTNMBR)
        {
            return KFH.BusinessMangers.ManualPaymentManger.GetSwiftReport(PMNTNMBR);
        }
        public List<Library.ManualPaymentPO> GetManualPaymentPO(string PMNTNMBR)
        {
            return KFH.BusinessMangers.ManualPaymentManger.GetManualPaymentPO(PMNTNMBR);
        }
        public List<Library.GLTransactions> GetGL(int JRNENTRY)
        {
            return KFH.BusinessMangers.ManualPaymentManger.GetGL(JRNENTRY);
        }
        public List<Library.ManualPaymentApprovalList> GetManualPaymentApprovalList(string BACHNUMB)
        {
            return KFH.BusinessMangers.ManualPaymentManger.GetManualPaymentApprovalList(BACHNUMB);
        }

        public List<Library.ManualPaymentApporvalValidation> getManualPaymentApporvalValidation(string BACHNUMB)
        {
            return KFH.BusinessMangers.ManualPaymentManger.getManualPaymentApporvalValidation(BACHNUMB);
        }

        public int GLTransactionEntryLineInsert(string BACHNUMB, int JRNENTRY, int ACTINDX, int ACTINDX2, string INTERID)
        {
            return KFH.BusinessMangers.GlTransactionEntry.GLTransactionEntryLineInsert(BACHNUMB, JRNENTRY, ACTINDX, ACTINDX2, INTERID);
        }

        #region Vendor

        public List<Library.PM00200> GetAllVendors()
        {
            return KFH.BusinessMangers.VendorManager.GetAllVendors();
        }

        public Library.PM00200 GetVendor(string VendorID)
        {
            return KFH.BusinessMangers.VendorManager.GetVendor(VendorID);
        }

        #endregion

        #region PM20000

        #endregion

        #region KIT_VendorInvoices
        public bool AddCustomVendorInvoice(Library.KIT_KFH_VendorInvoice newItem)
        {
            return KFH.BusinessMangers.CustomVendorInvoices.AddCustomVendorInvoice(newItem);
        }

        public List<Library.VindorInvoicesView> GetAllVednorInvoices()
        {
            return KFH.BusinessMangers.CustomVendorInvoices.GetAllVednorInvoices();
        }

        public Library.KIT_KFH_VendorInvoice GetVendorInvoice(string vchrNumber, int transactioID)
        {
            return KFH.BusinessMangers.CustomVendorInvoices.GetVendorInvoice(vchrNumber, transactioID);
        }

        public void DeleteVednorInvoices(List<KIT_KFH_VendorInvoice> deletedData)
        {
            KFH.BusinessMangers.CustomVendorInvoices.DeleteVednorInvoices(deletedData);
        }
        #endregion

        public List<Library.BatchApproval_TransactionLine> GetLineByBACHNUMB(string BACHNUMB)
        {
            return KFH.BusinessMangers.GLBatchApproval.GetLineByBACHNUMB(BACHNUMB);
        }
        public List<Library.GL10000> getGL10000(string BACHNUMB)
        {
            return KFH.BusinessMangers.GLBatchApproval.getGL10000(BACHNUMB);
        }

        //public List<Library.SourceDocumentByCurrency> GetSourceDocumentByCurrency(string CURNCYID)
        //{
        //    return KFH.BusinessMangers.GlTransactionEntry.GetSourceDocumentByCurrency(CURNCYID);
        //}

        public List<Library.SwiftExtendedAccounting> GetSwiftExtendedAccounting(string CURNCYID)
        {
            return KFH.BusinessMangers.GlTransactionEntry.GetSwiftExtendedAccounting(CURNCYID);
        }

        //public List<KFH.Library.GLtransactionEntryLine> GetGLtransactionEntryLine(int JRNENTRY)
        //{
        //    return KFH.BusinessMangers.GlTransactionEntry.GetGLtransactionEntryLine(JRNENTRY);
        //}
        //public List<KFH.Library.Swift01> GetSwift01(int JRNENTRY)
        //{
        //    return KFH.BusinessMangers.GlTransactionEntry.GetSwift01(JRNENTRY);
        //}
        //public List<KFH.Library.GLAccountReport> GetGLAccountReport(int JRNENTRY)
        //{
        //    return KFH.BusinessMangers.GlTransactionEntry.GetGLAccountReport(JRNENTRY);
        //}

        public List<Library.VendorInvoices> GetVendorInvoices(string vendorID, string CURNCYID)
        {
            List<Library.VendorInvoices> TempinvoicesList = new List<VendorInvoices>();
            List<Library.VendorInvoices> invoicesList = KFH.BusinessMangers.GlTransactionEntry.GetVendorInvoices(vendorID, CURNCYID);
            foreach (Library.VendorInvoices o in invoicesList)
            {
                Library.VendorInvoices temp = TempinvoicesList.Find(ee => ee.VCHRNMBR.Trim() == o.VCHRNMBR.Trim());
                if (temp == null)
                    TempinvoicesList.Add(o);
            }
            return TempinvoicesList;
        }
        public List<Library.VendorInvoices> GetVendorInvoicesDetails(string vendorID, string CURNCYID)
        {
            return KFH.BusinessMangers.GlTransactionEntry.GetVendorInvoices(vendorID, CURNCYID); ;
        }
        public List<Library.VendorInvoiceTable> GetVendorInvoiceTableByJRNENTRY(int JRNENTRY)
        {
            return KFH.BusinessMangers.GlTransactionEntry.GetVendorInvoiceTableByJRNENTRY(JRNENTRY);
        }

        public bool UpdateVendorInvoiceTable(List<Library.VendorInvoiceTable> VendorInvoiceTable)
        {
          return  KFH.BusinessMangers.GlTransactionEntry.UpdateVendorInvoiceTable(VendorInvoiceTable);
        }
        public bool UpdateGLVendorTable(int JRNENTRY, string VENDORID, string VENDNAME)
        {
            return KFH.BusinessMangers.GlTransactionEntry.UpdateGLVendorTable(JRNENTRY, VENDORID, VENDNAME);
        }
       
        //public List<SwiftReport> GetGLSwiftReport(int JRNENTRY)
        //{
        //    return KFH.BusinessMangers.GlTransactionEntry.GetGLSwiftReport(JRNENTRY);
        //}
        public List<SwiftGL> getSwiftGL(int JRNENTRY)
        {
            return KFH.BusinessMangers.GlTransactionEntry.getSwiftGL(JRNENTRY);
        }
        public List<SwiftVendor> getSwiftVendor(int JRNENTRY)
        {
            return KFH.BusinessMangers.GlTransactionEntry.getSwiftVendor(JRNENTRY);
        }


        public bool RunCurrencyIntegration(DateTime dt)
        {
            return KFH.BusinessMangers.GlTransactionEntry.RunCurrencyIntegration2(dt);
        }

        #region GL00100

        public DataCollection<Library.GL00100> GetGLAccountsWithPaging(int PageSize, int CurrentPage, string filter)
        {
            return KFH.BusinessMangers.GlTransactionEntry.GetGLAccountsWithPaging(PageSize, CurrentPage, filter);
        }

        public List<Library.GL00100> GetAllAccounts()
        {
            return KFH.BusinessMangers.GlTransactionEntry.GetAllAccounts();
        }
        #endregion

        #region pay to account
        public bool Add_PaytoAccount(Library.KIT_KFH_PayToAccount item)
        {
            return KFH.BusinessMangers.GlTransactionEntry.Add_PaytoAccount(item);
        }
        #endregion 

    }
}

